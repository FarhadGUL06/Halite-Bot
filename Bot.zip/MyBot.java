import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

public class MyBot {
    InitPackage iPackage;
    int myID;
    GameMap gameMap;
    int numberOfFrames;
    ArrayList<Location> cells;
    HashMap<Location, Integer> isDanger;
    int minX, maxX, minY, maxY;
    int dx[] = {-1, 0, 1, 0};
    int dy[] = {0, 1, 0, -1};
    int[][] TableOfSums;
    class PerecheScor {
        Location loc;
        int score;
        public PerecheScor(Location loc, int score) {
            this.loc = loc;
            this.score = score;
        }
    }
    class PerecheScorComparator implements Comparator<PerecheScor> {
        @Override
        public int compare(MyBot.PerecheScor s1, MyBot.PerecheScor s2) {
            
            if (s1.score < s2.score) {
                return 1;
            }
            if (s1.score > s2.score) {
                return -1;
            }
            return 0;
        }
    }
    PriorityQueue <PerecheScor> pq = new PriorityQueue<PerecheScor>(10000, 
                                         new PerecheScorComparator());
    public MyBot () {
        iPackage = Networking.getInit();
        myID = iPackage.myID;
        gameMap = iPackage.map;
        cells = new ArrayList<Location>();
        numberOfFrames = 1;
        minX = gameMap.width;
        maxX = 0;
        minY = gameMap.height;
        maxY = 0;
        isDanger = new HashMap<Location, Integer>();
    } 
    boolean is_on_border (Location location) {
        Site site = location.getSite();
        if (site.owner != 0)
            return false;
        for (int i = 0; i <= 3; i++) {
            Location neigh = gameMap.getLocation(location, Direction.CARDINALS[i]);
            Site neighSite = neigh.getSite();
            if (neighSite.owner == myID) {
                return true;
            }
        }
        return false;
    }
    public void UpdateTable() {
        int height = gameMap.height, width = gameMap.width;
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                Location location = gameMap.getLocation(x, y);
                Site site = location.getSite();
                if (is_on_border(location)) {
                    TableOfSums[x][y] = site.production * 5 -
                                        (site.strength * 7 / 10) + 50;
                    PerecheScor PS = new PerecheScor(location, 
                                         TableOfSums[x][y]);
                    pq.add(PS);
                }
            }
        }
    }
    public void initTOS() {
        int height = gameMap.height, width = gameMap.width;
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                 TableOfSums[x][y] = 0;
            }
        }
    }
    public void UpdateTableInside() {
        while(!pq.isEmpty()) {
            PerecheScor PsAux = pq.peek();
            pq.poll();
            Site site = PsAux.loc.getSite();
            for (int i = 0; i <= 3; ++i) {
                Location neigh = gameMap.getLocation
                (PsAux.loc, Direction.CARDINALS[i]);
                if(neigh.getSite().owner == myID)
                    {
                        int yy = neigh.getY();
                        int xx = neigh.getX();
                        int exX = PsAux.loc.getX();
                        int exY = PsAux.loc.getY();
                        if (TableOfSums[xx][yy] == 0) {
                            TableOfSums[xx][yy] = 
                            TableOfSums[exX][exY] - neigh.getSite().production 
                                                - 2;
                            PerecheScor BackToPQ = new PerecheScor(neigh,
                            TableOfSums[xx][yy]);
                            pq.add(BackToPQ);
                        }
                    }
            }
        }
    }
    public void initial () {
        // Desfasurarea jocului efectiva
        ArrayList<Location> newCells = new ArrayList<>();
        TableOfSums = new int[gameMap.height+2][gameMap.width+2];
        Networking.sendInit("OdoBot");
        //start_location();
        while(true) {
        List<Move> moves = new ArrayList<Move>();
        Networking.updateFrame(gameMap);
        // isDanger.clear();
        initTOS();
        UpdateTable();
        UpdateTableInside();
         for (int y = 0; y < gameMap.height; y++) {
            for (int x = 0; x < gameMap.width; x++) {
                int finalDirection = -1, maxScore = -99999, finalAdvancedDirection = -1, maxAdvancedScore = -99999;
                Location location = gameMap.getLocation(x, y);
                Site site = location.getSite();
                if (site.owner != myID) {
                    continue;
                }
                if (site.strength < 6 * site.production) {
                    moves.add(new Move(location, Direction.STILL));
                    continue;
                }
                for (int i = 0; i <= 3; ++i) {
                    Location LocAux = gameMap.getLocation(location, Direction.CARDINALS[i]);
                    if (TableOfSums[LocAux.getX()][LocAux.getY()] > maxScore) {
                        maxScore = TableOfSums[LocAux.getX()][LocAux.getY()];
                        finalDirection = i;
                    }
                }
                Location newLoc;
                newLoc = gameMap.getLocation(location, Direction.CARDINALS[finalDirection]);
                if (site.strength < newLoc.getSite().strength) {
                    moves.add(new Move(location, Direction.STILL));
                    continue;
                }
                moves.add(new Move(location, Direction.CARDINALS[finalDirection]));
            } // al doilea for
         } // primul for
        Networking.sendFrame(moves);
         } // while (true)
    } // final functie
    public static void main(String[] args) throws java.io.IOException {
        MyBot mybot = new MyBot();
        mybot.initial();
    }
}
